Sample configuration files for:

SystemD: bitcoinoceand.service
Upstart: bitcoinoceand.conf
OpenRC:  bitcoinoceand.openrc
         bitcoinoceand.openrcconf
CentOS:  bitcoinoceand.init
OS X:    org.bitcoinocean.bitcoinoceand.plist

have been made available to assist packagers in creating node packages here.

See doc/init.md for more information.
