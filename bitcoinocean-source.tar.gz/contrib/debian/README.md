
Debian
====================
This directory contains files used to package bitcoinoceand/bitcoinocean-qt
for Debian-based Linux systems. If you compile bitcoinoceand/bitcoinocean-qt yourself, there are some useful files here.

## bitcoinocean: URI support ##


bitcoinocean-qt.desktop  (Gnome / Open Desktop)
To install:

	sudo desktop-file-install bitcoinocean-qt.desktop
	sudo update-desktop-database

If you build yourself, you will either need to modify the paths in
the .desktop file or copy or symlink your bitcoinocean-qt binary to `/usr/bin`
and the `../../share/pixmaps/bitcoinocean128.png` to `/usr/share/pixmaps`

bitcoinocean-qt.protocol (KDE)

