#!/bin/bash
# use testnet settings,  if you need mainnet,  use ~/.bitcoinoceancore/bitcoinoceand.pid file instead
bitcoinocean_pid=$(<~/.bitcoinoceancore/testnet3/bitcoinoceand.pid)
sudo gdb -batch -ex "source debug.gdb" bitcoinoceand ${bitcoinocean_pid}
